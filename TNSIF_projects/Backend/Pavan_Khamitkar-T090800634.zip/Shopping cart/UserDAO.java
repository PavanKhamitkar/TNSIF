import java.sql.*;

public class UserDAO {

    public boolean registerUser(String username, String email, String password, String userType) {
        String query = "INSERT INTO Users (username, email, password, userType) VALUES (?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, username);
            pst.setString(2, email);
            pst.setString(3, password); 
            pst.setString(4, userType);

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println(" Error registering user: " + e.getMessage());
        }
        return false;
    }

    public boolean validateUser(String username, String password, String userType) {
        String query = "SELECT password FROM Users WHERE username = ? AND userType = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, username);
            pst.setString(2, userType);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return password.equals(rs.getString("password")); 
                }
            }
        } catch (SQLException e) {
            System.err.println(" Error validating user: " + e.getMessage());
        }
        return false;
    }

    public User getUserByUsername(String username) {
        String query = "SELECT * FROM Users WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return new User(rs.getInt("userId"), rs.getString("username"), rs.getString("email"),
                        rs.getString("password"), rs.getString("userType"));
            }
        } catch (SQLException e) {
            System.err.println(" Error fetching user: " + e.getMessage());
        }
        return null;
    }

    public boolean updateUserProfile(int userId, String email) {
        String query = "UPDATE Users SET email = ? WHERE userId = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, email);
            pst.setInt(2, userId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println(" Error updating profile: " + e.getMessage());
        }
        return false;
    }
}
