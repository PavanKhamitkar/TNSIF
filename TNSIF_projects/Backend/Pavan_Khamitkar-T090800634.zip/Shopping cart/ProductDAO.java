import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    
    // Add Product
    public boolean addProduct(Product product) {
        String query = "INSERT INTO Products (name, price, stockQuantity) VALUES (?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, product.getName());
            pst.setDouble(2, product.getPrice());
            pst.setInt(3, product.getStockQuantity());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Error adding product: " + e.getMessage());
        }
        return false;
    }

    // Update Product
    public boolean updateProduct(int productId, String name, double price, int stockQuantity) {
        String query = "UPDATE Products SET name = ?, price = ?, stockQuantity = ? WHERE productId = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, name);
            pst.setDouble(2, price);
            pst.setInt(3, stockQuantity);
            pst.setInt(4, productId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Error updating product: " + e.getMessage());
        }
        return false;
    }

    // Delete Product
    public boolean deleteProduct(int productId) {
        String query = "DELETE FROM Products WHERE productId = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, productId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Error deleting product: " + e.getMessage());
        }
        return false;
    }

    // Get All Products
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        String query = "SELECT * FROM Products";
        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                productList.add(new Product(
                    rs.getInt("productId"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getInt("stockQuantity")
                ));
            }
        } catch (SQLException e) {
            System.err.println("❌ Error fetching products: " + e.getMessage());
        }
        return productList;
    }

    // ✅ Implementing `getProductById`
    public Product getProductById(int productId) {
        String query = "SELECT * FROM Products WHERE productId = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, productId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return new Product(
                        rs.getInt("productId"),
                        rs.getString("name"),
                        rs.getDouble("price"),
                        rs.getInt("stockQuantity")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error fetching product by ID: " + e.getMessage());
        }
        return null; // Product not found
    }
}
