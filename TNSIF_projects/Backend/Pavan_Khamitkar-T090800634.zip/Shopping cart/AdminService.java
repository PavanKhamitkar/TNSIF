import java.util.List;

public class AdminService {
    private ProductDAO productDAO = new ProductDAO();

    // Add a new product
    public void addProduct(String name, double price, int stockQuantity) {
        Product product = new Product(0, name, price, stockQuantity);
        boolean success = productDAO.addProduct(product);
        if (success) {
            System.out.println(" Product added successfully!");
        } else {
            System.out.println(" Failed to add product.");
        }
    }

    // View all products
    public void viewProducts() {
        List<Product> products = productDAO.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("⚠ No products found.");
        } else {
            products.forEach(System.out::println);
        }
    }

    // Remove a product by ID
    public void removeProduct(int productId) {
        boolean success = productDAO.deleteProduct(productId);
        if (success) {
            System.out.println(" Product removed successfully!");
        } else {
            System.out.println(" Product not found or deletion failed.");
        }
    }

    // Update an existing product
    public void updateProduct(int productId, String name, double price, int stockQuantity) {
        boolean success = productDAO.updateProduct(productId, name, price, stockQuantity);
        if (success) {
            System.out.println("✅ Product updated successfully!");
        } else {
            System.out.println("❌ Failed to update product. Product ID may not exist.");
        }
    }
}
