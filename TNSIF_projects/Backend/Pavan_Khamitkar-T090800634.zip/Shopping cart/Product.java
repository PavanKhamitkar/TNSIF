public class Product {
    private int productId;
    private String name;
    private double price;
    private int stockQuantity;

    // Constructor
    public Product(int productId, String name, double price, int stockQuantity) {
        this.productId = productId;
        this.name = name;
        setPrice(price); // Use setter for validation
        setStockQuantity(stockQuantity);
    }

    
    // Getters
    public int getProductId() { return productId; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStockQuantity() { return stockQuantity; }

    // Setters with Validation
    public void setProductId(int productId) { this.productId = productId; }
    public void setName(String name) { this.name = name; }
    
    public void setPrice(double price) { 
        if (price > 0) {
            this.price = price;
        } else {
            throw new IllegalArgumentException("Price must be greater than zero.");
        }
    }

    public void setStockQuantity(int stockQuantity) {
        if (stockQuantity >= 0) {
            this.stockQuantity = stockQuantity;
        } else {
            throw new IllegalArgumentException("Stock quantity cannot be negative.");
        }
    }

    // toString Method
    @Override
    public String toString() {
        return "Product [ID=" + productId + ", Name=" + name + ", Price=" + price + ", Stock=" + stockQuantity + "]";
    }
}
