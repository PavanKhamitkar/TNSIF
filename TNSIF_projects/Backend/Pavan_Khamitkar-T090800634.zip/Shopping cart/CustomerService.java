import java.util.HashMap;
import java.util.Map;

public class CustomerService {
    private ProductDAO productDAO = new ProductDAO();
    private Map<String, ShoppingCart> userCarts = new HashMap<>(); // Stores carts for each user

    public void viewProducts() {
        productDAO.getAllProducts().forEach(System.out::println);
    }

    public void addToCart(String username, int productId, int quantity) {
        Product product = productDAO.getProductById(productId);
        if (product == null) {
            System.out.println("❌ Product not found.");
            return;
        }
        if (quantity <= 0) {
            System.out.println("❌ Invalid quantity. Please enter a positive number.");
            return;
        }
        if (product.getStockQuantity() < quantity) {
            System.out.println("❌ Not enough stock available.");
            return;
        }

        // Get or create user's cart
        ShoppingCart cart = userCarts.getOrDefault(username, new ShoppingCart());
        cart.addProduct(product, quantity);
        userCarts.put(username, cart);

        System.out.println("✅ Product added to cart!");
    }

    public void viewCart(String username) {
        ShoppingCart cart = userCarts.get(username);
        if (cart == null || cart.isEmpty()) {
            System.out.println("🛒 Your cart is empty.");
        } else {
            cart.viewCart();
        }
    }

    public void placeOrder(String username) {
        ShoppingCart cart = userCarts.get(username);
        if (cart == null || cart.isEmpty()) {
            System.out.println("❌ Your cart is empty. Add products before placing an order.");
            return;
        }

        // Here, we would normally process payment and update stock in the database
        System.out.println("✅ Order placed successfully!");
        userCarts.remove(username); // Clear cart after order
    }
}
