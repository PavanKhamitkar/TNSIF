import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/OnlineShoppingDB?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USER = "root";  
    private static final String PASSWORD = "root";  

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Ensure the MySQL Driver is loaded
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC Driver not found! Ensure mysql-connector-java-9.2.0.jar is added.", e);
        }
    }

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException("Database connection failed! Check MySQL status and credentials.", e);
        }
    }
}
