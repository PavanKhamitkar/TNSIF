import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static UserDAO userDAO = new UserDAO();
    private static AdminService adminService = new AdminService();
    private static CustomerService customerService = new CustomerService();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nWelcome to Online Shopping System");
            System.out.println("1. Admin Login");
            System.out.println("2. Customer Login");
            System.out.println("3. Register as Customer");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            if (!scanner.hasNextInt()) {
                scanner.next();
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    authenticateUser("Admin");
                    break;
                case 2:
                    authenticateUser("Customer");
                    break;
                case 3:
                    registerUser();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }

    private static void registerUser() {
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
    
        if (userDAO.registerUser(username, email, password, "Customer")) {
            System.out.println("✅ User registered successfully!");
        } else {
            System.out.println("❌ Registration failed.");
        }
    }
    
    private static void authenticateUser(String userType) {
        System.out.print("\nEnter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        if (userDAO.validateUser(username, password, userType)) {
            System.out.println("Login successful!\n");
            if (userType.equals("Admin")) {
                adminMenu();
            } else {
                customerMenu(username);
            }
        } else {
            System.out.println("Invalid credentials. Try again.");
        }
    }

    private static void adminMenu() {
        while (true) {
            System.out.println("\nAdmin Menu:");
            System.out.println("1. Add Product");
            System.out.println("2. View Products");
            System.out.println("3. Logout");
            System.out.print("Choose an option: ");

            if (!scanner.hasNextInt()) {
                scanner.next();
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    adminService.viewProducts();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void addProduct() {
        System.out.print("Enter Product Name: ");
        String name = scanner.nextLine();

        double price;
        while (true) {
            System.out.print("Enter Price: ");
            if (scanner.hasNextDouble()) {
                price = scanner.nextDouble();
                if (price > 0) break;
            }
            scanner.nextLine();
            System.out.println("Invalid price. Please enter a positive number.");
        }

        int stock;
        while (true) {
            System.out.print("Enter Stock Quantity: ");
            if (scanner.hasNextInt()) {
                stock = scanner.nextInt();
                if (stock >= 0) break;
            }
            scanner.nextLine();
            System.out.println("Invalid stock quantity. Please enter a non-negative number.");
        }

        scanner.nextLine(); // Consume newline
        adminService.addProduct(name, price, stock);
    }

    private static void customerMenu(String username) {
        while (true) {
            System.out.println("\nCustomer Menu:");
            System.out.println("1. View Products");
            System.out.println("2. Add to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Place Order");
            System.out.println("5. Logout");
            System.out.print("Choose an option: ");
    
            if (!scanner.hasNextInt()) {
                scanner.next();
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine();
    
            switch (choice) {
                case 1:
                    customerService.viewProducts();
                    break;
                case 2:
                    addToCart(username);
                    break;
                case 3:
                    customerService.viewCart(username);
                    break;
                case 4:
                    customerService.placeOrder(username);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void addToCart(String username) {
        System.out.print("Enter Product ID: ");
        if (!scanner.hasNextInt()) {
            scanner.next();
            System.out.println("Invalid input. Please enter a valid Product ID.");
            return;
        }
        int productId = scanner.nextInt();

        System.out.print("Enter Quantity: ");
        if (!scanner.hasNextInt()) {
            scanner.next();
            System.out.println("Invalid input. Please enter a valid quantity.");
            return;
        }
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        customerService.addToCart(username, productId, quantity);
    }
}

class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/OnlineShoppingDB?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found! Make sure mysql-connector-java is added.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection failed! Check MySQL status and credentials.");
            e.printStackTrace();
        }
        return null;
    }
}
